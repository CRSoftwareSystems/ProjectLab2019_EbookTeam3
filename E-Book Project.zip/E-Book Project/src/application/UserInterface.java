package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class UserInterface extends Application implements Initializable {
	
	
	@FXML
	private Button login;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML 
	private RadioButton reader;
	@FXML 
	private RadioButton author;
	@FXML 
	private RadioButton admin;
	@FXML
	private Label message;
	
	
	  public void homeWindow(ActionEvent event) {
		  message.setText("");
			String checkuser = username.getText().toString();
			String checkpass = password.getText().toString();
			
			if (checkuser.equals("team3") && checkpass.equals("123")
					|| (checkuser.equals("Team3") && checkpass.equals("123"))) {			
				 try {
			            // Read file fxml and draw interface.
			        	
			        	FXMLLoader fxmlLoader = new FXMLLoader(getClass() 
			                    .getResource("/application/HomeWindow.fxml"));
			        	Parent root1 = (Parent) fxmlLoader.load();
			        	Stage mainStage = new Stage();	 
			            mainStage.setTitle("Reader's Hub");
			            mainStage.setScene(new Scene(root1));
			            mainStage.show();
			            	       
			        } catch(Exception e) {
			            e.printStackTrace();
			            System.out.println("Can't Load the window");
			        }		
			}
			else
			message.setText("Please Enter Correct Credentials");
	    }
	
	
	
	@Override
	public void start(Stage arg0) throws Exception {
		
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	
		
	}
	

}
		
